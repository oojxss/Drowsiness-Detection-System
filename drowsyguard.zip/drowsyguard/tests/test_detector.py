"""
DrowsyGuard — tests/test_detector.py
Unit tests for EAR, PERCLOS, and risk score functions.
Run with: pytest tests/ -v
"""

import numpy as np
import pytest
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.detector import compute_ear, mean_ear, PerclosCalculator, compute_risk_score
from src.config   import EAR_THRESHOLD, PERCLOS_THRESHOLD, SCORE_ALERT


# ── EAR tests ────────────────────────────────────────────────────────────────
class TestComputeEar:
    def _eye(self, height: float) -> np.ndarray:
        """Synthetic eye: width=40, configurable height."""
        return np.array([
            [0,  0],      # p1 outer corner
            [10, -height],# p2 upper lid
            [30, -height],# p3 upper lid
            [40, 0],      # p4 inner corner
            [30, height], # p5 lower lid
            [10, height], # p6 lower lid
        ], dtype=np.float64)

    def test_open_eye_above_threshold(self):
        ear = compute_ear(self._eye(8))
        assert ear > EAR_THRESHOLD, f"Open eye EAR {ear:.3f} should be > {EAR_THRESHOLD}"

    def test_closed_eye_below_threshold(self):
        ear = compute_ear(self._eye(1))
        assert ear < EAR_THRESHOLD, f"Closed eye EAR {ear:.3f} should be < {EAR_THRESHOLD}"

    def test_returns_float(self):
        assert isinstance(compute_ear(self._eye(6)), float)

    def test_symmetric_eyes_equal(self):
        """Left and right eye with same geometry should yield same EAR."""
        eye = self._eye(7)
        assert compute_ear(eye) == pytest.approx(compute_ear(eye))


# ── PERCLOS tests ─────────────────────────────────────────────────────────────
class TestPerclosCalculator:
    def test_all_open_gives_zero(self):
        p = PerclosCalculator(fps=10, window_seconds=5)
        for _ in range(50):
            val = p.update(0.35)   # clearly open
        assert val == pytest.approx(0.0)

    def test_all_closed_gives_one(self):
        p = PerclosCalculator(fps=10, window_seconds=5)
        for _ in range(50):
            val = p.update(0.10)   # clearly closed
        assert val == pytest.approx(1.0)

    def test_half_closed_gives_half(self):
        p = PerclosCalculator(fps=10, window_seconds=2)
        for _ in range(10):
            p.update(0.10)   # closed
        for _ in range(10):
            p.update(0.35)   # open
        assert p.value == pytest.approx(0.5)

    def test_old_frames_evicted(self):
        """Buffer should forget frames older than window."""
        p = PerclosCalculator(fps=10, window_seconds=1)
        for _ in range(10):
            p.update(0.10)   # fill with closed
        for _ in range(10):
            p.update(0.35)   # overwrite with open
        assert p.value == pytest.approx(0.0)


# ── Risk Score tests ──────────────────────────────────────────────────────────
class TestComputeRiskScore:
    def test_alert_driver_low_score(self):
        score = compute_risk_score(ear=0.35, perclos=0.02, pitch=2.0, yaw=1.0)
        assert score < SCORE_ALERT

    def test_drowsy_driver_high_score(self):
        score = compute_risk_score(ear=0.12, perclos=0.30, pitch=25.0, yaw=5.0)
        assert score >= SCORE_ALERT

    def test_score_in_range(self):
        for ear in [0.10, 0.25, 0.40]:
            for perclos in [0.0, 0.15, 0.50]:
                score = compute_risk_score(ear, perclos, 0, 0)
                assert 0 <= score <= 100, f"Score {score} out of range"

    def test_low_ear_alone_raises_score(self):
        low  = compute_risk_score(ear=0.12, perclos=0.0, pitch=0.0, yaw=0.0)
        high = compute_risk_score(ear=0.35, perclos=0.0, pitch=0.0, yaw=0.0)
        assert low > high
