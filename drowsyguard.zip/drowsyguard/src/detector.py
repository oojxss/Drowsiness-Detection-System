"""
DrowsyGuard — src/detector.py
Core detection pipeline: EAR + PERCLOS + Head Pose + Risk Score Fusion.

Reference: Soukupová & Čech, "Real-Time Eye Blink Detection using
           Facial Landmarks", CVWW 2016.
"""

import cv2
import dlib
import numpy as np
import time
import logging
from collections import deque
from scipy.spatial import distance as dist
from imutils import face_utils

from .config import (
    EAR_THRESHOLD, EAR_CONSEC_FRAMES,
    PERCLOS_THRESHOLD, HEAD_PITCH_THRESH, HEAD_YAW_THRESH,
    WINDOW_SECONDS, SCORE_ALERT,
    W_EAR, W_PERCLOS, W_HEAD,
)
from .alerts import AlertManager

logger = logging.getLogger(__name__)

# ── Landmark indices (dlib 68-point model) ───────────────────────────────────
L_START, L_END = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
R_START, R_END = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]

# Generic 3-D face model for solvePnP (millimetres, facing camera)
MODEL_POINTS_3D = np.array([
    (0.0,     0.0,    0.0),    # Nose tip        [landmark 30]
    (0.0,  -330.0,  -65.0),    # Chin            [landmark 8]
    (-225.0, 170.0, -135.0),   # Left eye outer  [landmark 36]
    (225.0,  170.0, -135.0),   # Right eye outer [landmark 45]
    (-150.0,-150.0, -125.0),   # Left mouth      [landmark 48]
    (150.0, -150.0, -125.0),   # Right mouth     [landmark 54]
], dtype=np.float64)
LANDMARK_2D_IDX = [30, 8, 36, 45, 48, 54]


# ── EAR ──────────────────────────────────────────────────────────────────────
def compute_ear(eye: np.ndarray) -> float:
    """
    Eye Aspect Ratio for one eye (requires exactly 6 landmark points).

    Formula:
        EAR = (||p2-p6|| + ||p3-p5||) / (2 * ||p1-p4||)

    Where p1..p6 are the six eye landmark coordinates in clockwise order:
    p1=outer corner, p2/p3=upper lid, p4=inner corner, p5/p6=lower lid.

    Returns
    -------
    float
        Open eye ≈ 0.30-0.40  |  Closed eye ≈ 0.05-0.15
    """
    A = dist.euclidean(eye[1], eye[5])   # vertical distance (upper-lower)
    B = dist.euclidean(eye[2], eye[4])   # vertical distance (upper-lower)
    C = dist.euclidean(eye[0], eye[3])   # horizontal distance (width)
    return (A + B) / (2.0 * C)


def mean_ear(shape: np.ndarray) -> float:
    """
    Average EAR across both eyes.

    Parameters
    ----------
    shape : np.ndarray of shape (68, 2)
        Full dlib facial landmark array.
    """
    left  = compute_ear(shape[L_START:L_END])
    right = compute_ear(shape[R_START:R_END])
    return (left + right) / 2.0


# ── Head Pose ─────────────────────────────────────────────────────────────────
def estimate_head_pose(shape: np.ndarray,
                       frame_shape: tuple) -> tuple[float, float, float]:
    """
    Estimate head rotation (pitch, yaw, roll) via OpenCV solvePnP.

    Maps 6 stable 2-D facial landmarks to a known 3-D face model,
    then decomposes the rotation matrix into Euler angles.

    Parameters
    ----------
    shape       : (68, 2) landmark array
    frame_shape : (height, width, channels) tuple from frame.shape

    Returns
    -------
    (pitch, yaw, roll) in degrees
        pitch > 0 → nodding down
        yaw   > 0 → turning right
    """
    h, w = frame_shape[:2]
    focal = w
    cam_matrix = np.array([
        [focal, 0,     w / 2],
        [0,     focal, h / 2],
        [0,     0,     1    ],
    ], dtype=np.float64)

    pts2d = np.array([shape[i] for i in LANDMARK_2D_IDX], dtype=np.float64)
    ok, rvec, _ = cv2.solvePnP(
        MODEL_POINTS_3D, pts2d, cam_matrix,
        np.zeros((4, 1)), flags=cv2.SOLVEPNP_ITERATIVE
    )
    if not ok:
        return 0.0, 0.0, 0.0

    rmat, _ = cv2.Rodrigues(rvec)
    angles, *_ = cv2.RQDecomp3x3(rmat)
    return float(angles[0]), float(angles[1]), float(angles[2])


# ── PERCLOS ───────────────────────────────────────────────────────────────────
class PerclosCalculator:
    """
    Rolling-window PERCLOS (PERcentage of eye CLOSure).

    Maintains a fixed-size buffer of binary closed/open samples.
    PERCLOS = sum(closed frames) / total frames in window.

    NHTSA standard: > 15 % closure over 60 s → drowsy.
    """

    def __init__(self, fps: float = 30.0,
                 window_seconds: float = WINDOW_SECONDS):
        """
        Parameters
        ----------
        fps            : Camera frame rate (sets buffer size).
        window_seconds : Rolling window length in seconds.
        """
        self._buf: deque[int] = deque(maxlen=int(fps * window_seconds))

    def update(self, ear: float) -> float:
        """
        Push a new EAR sample. Returns current PERCLOS value.

        Parameters
        ----------
        ear : Current frame mean EAR value.

        Returns
        -------
        float in [0, 1]
        """
        self._buf.append(1 if ear < EAR_THRESHOLD else 0)
        return self.value

    @property
    def value(self) -> float:
        """Current PERCLOS without pushing a new sample."""
        if not self._buf:
            return 0.0
        return sum(self._buf) / len(self._buf)


# ── Risk Score Fusion ─────────────────────────────────────────────────────────
def compute_risk_score(ear: float, perclos: float,
                       pitch: float, yaw: float) -> int:
    """
    Fuse EAR, PERCLOS, and head pose into a single [0, 100] risk score.

    Weighted formula (weights from config.py):
        EAR component    = (1 - EAR / threshold) × W_EAR
        PERCLOS component = (PERCLOS / threshold) × W_PERCLOS
        Head component   = (deviation / threshold) × W_HEAD

    Parameters
    ----------
    ear     : Mean EAR value for this frame.
    perclos : Current PERCLOS ratio (0–1).
    pitch   : Head pitch in degrees.
    yaw     : Head yaw in degrees.

    Returns
    -------
    int in [0, 100]. Score ≥ SCORE_ALERT triggers an alert.
    """
    ear_c  = max(0.0, (1 - ear / EAR_THRESHOLD)) * W_EAR
    perc_c = min(perclos / PERCLOS_THRESHOLD, 1.0) * W_PERCLOS
    head_c = min(
        (abs(pitch) / HEAD_PITCH_THRESH + abs(yaw) / HEAD_YAW_THRESH) / 2,
        1.0
    ) * W_HEAD
    return int(min(ear_c + perc_c + head_c, 100))


# ── HUD Overlay ───────────────────────────────────────────────────────────────
def _draw_hud(frame: np.ndarray, ear: float, perclos: float,
              pitch: float, yaw: float, score: int,
              blinks: int, alerts: int) -> np.ndarray:
    """Render metrics HUD onto a video frame. Mutates and returns frame."""
    h, w = frame.shape[:2]

    def _col(val, lo, hi):
        if val < lo: return (0, 200, 100)
        if val < hi: return (0, 180, 255)
        return (0, 60, 220)

    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (305, 175), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.45, frame, 0.55, 0, frame)

    rows = [
        (f"EAR:     {ear:.3f}",         _col(ear, 0.25, 0.20)),
        (f"PERCLOS: {perclos*100:.1f}%", _col(perclos, 0.10, 0.15)),
        (f"Pitch:   {pitch:.1f} deg",    _col(abs(pitch), 15, 20)),
        (f"Yaw:     {yaw:.1f} deg",      _col(abs(yaw), 20, 30)),
        (f"Blinks:  {blinks}",           (160, 220, 160)),
        (f"Alerts:  {alerts}",           (120, 160, 255)),
    ]
    for i, (txt, color) in enumerate(rows):
        cv2.putText(frame, txt, (10, 28 + i * 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.58, color, 1, cv2.LINE_AA)

    bx, by, bw, bh = w - 185, 12, 170, 30
    fill = int(bw * score / 100)
    bc   = _col(score, 35, 65)
    cv2.rectangle(frame, (bx, by), (bx + bw, by + bh), (35, 35, 35), -1)
    cv2.rectangle(frame, (bx, by), (bx + fill, by + bh), bc, -1)
    cv2.putText(frame, f"RISK: {score}/100", (bx + 6, by + 21),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

    if score >= SCORE_ALERT:
        cv2.rectangle(frame, (0, 0), (w, h), (0, 40, 200), 5)
        cv2.putText(frame, "!! DROWSINESS ALERT !!",
                    (w // 2 - 190, h - 22),
                    cv2.FONT_HERSHEY_DUPLEX, 0.85, (0, 60, 255), 2)
    return frame


# ── Main Detector Class ───────────────────────────────────────────────────────
class DrowsinessDetector:
    """
    Full real-time drowsiness detection pipeline.

    Combines:
    - dlib HOG face detection + 68-point shape predictor
    - EAR-based instantaneous eye-closure detection
    - PERCLOS rolling-window metric (NHTSA standard)
    - Head pose estimation via OpenCV solvePnP
    - Weighted risk score fusion with alert system

    Parameters
    ----------
    predictor_path : Path to dlib's shape_predictor_68_face_landmarks.dat
    camera_index   : cv2.VideoCapture device index (0 = default webcam)
    fps            : Expected camera frame rate (affects PERCLOS window)

    Example
    -------
    >>> d = DrowsinessDetector("models/shape_predictor_68_face_landmarks.dat")
    >>> d.run()   # press Q to quit
    """

    def __init__(self, predictor_path: str,
                 camera_index: int = 0,
                 fps: float = 30.0):
        logger.info("Loading dlib models…")
        self.detector  = dlib.get_frontal_face_detector()
        self.predictor = dlib.shape_predictor(predictor_path)

        self.cap = cv2.VideoCapture(camera_index)
        self.cap.set(cv2.CAP_PROP_FPS, fps)

        self.perclos     = PerclosCalculator(fps=fps)
        self.alerts_mgr  = AlertManager()
        self.blink_count = 0
        self._ear_below  = 0
        self.start_time  = time.time()
        logger.info("DrowsyGuard ready. Press Q to quit.")

    def run(self) -> None:
        """
        Main detection loop.

        Each iteration:
        1. Grab frame from camera
        2. Convert to grayscale for face detection
        3. Detect faces via dlib HOG detector
        4. Predict 68 facial landmarks
        5. Compute mean EAR, PERCLOS, head pose
        6. Fuse into risk score
        7. Trigger alert if score ≥ threshold
        8. Render HUD overlay and display
        """
        while True:
            ret, frame = self.cap.read()
            if not ret:
                logger.warning("Failed to grab frame.")
                break

            gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.detector(gray, 0)

            ear, perclos_v = 0.35, 0.0
            pitch = yaw = 0.0
            score = 0

            for face in faces:
                shape     = face_utils.shape_to_np(self.predictor(gray, face))
                ear       = mean_ear(shape)
                perclos_v = self.perclos.update(ear)
                pitch, yaw, _ = estimate_head_pose(shape, frame.shape)
                score     = compute_risk_score(ear, perclos_v, pitch, yaw)

                # Blink detection: count closed→open transitions
                if ear < EAR_THRESHOLD:
                    self._ear_below += 1
                else:
                    if self._ear_below >= EAR_CONSEC_FRAMES:
                        self.blink_count += 1
                    self._ear_below = 0

                if score >= SCORE_ALERT:
                    self.alerts_mgr.trigger(score, ear, perclos_v)

                # Draw landmark dots
                for x, y in shape:
                    cv2.circle(frame, (x, y), 1, (0, 212, 255), -1)

            frame = _draw_hud(
                frame, ear, perclos_v, pitch, yaw,
                score, self.blink_count, self.alerts_mgr.count
            )
            cv2.imshow("DrowsyGuard", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        self._cleanup()

    def _cleanup(self) -> None:
        elapsed = time.time() - self.start_time
        logger.info(
            f"Session ended — {elapsed:.0f}s | "
            f"blinks={self.blink_count} | alerts={self.alerts_mgr.count}"
        )
        self.cap.release()
        cv2.destroyAllWindows()
