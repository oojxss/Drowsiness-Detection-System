"""DrowsyGuard — real-time driver drowsiness detection."""
from .detector import DrowsinessDetector, compute_ear, mean_ear, compute_risk_score
from .config import *

__all__ = [
    "DrowsinessDetector",
    "compute_ear",
    "mean_ear",
    "compute_risk_score",
]
