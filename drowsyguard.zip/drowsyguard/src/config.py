"""
DrowsyGuard — src/config.py
All tunable thresholds and weights in one place.
Change values here; no need to touch detector.py.
"""

# ── EAR ─────────────────────────────────────────────────────────────────────
EAR_THRESHOLD     = 0.25   # Below → eye considered closed
EAR_CONSEC_FRAMES = 3      # Frames below threshold to register a blink

# ── PERCLOS ──────────────────────────────────────────────────────────────────
PERCLOS_THRESHOLD = 0.15   # 15 % closure → drowsy (NHTSA standard)
WINDOW_SECONDS    = 60     # Rolling window length in seconds

# ── Head Pose ────────────────────────────────────────────────────────────────
HEAD_PITCH_THRESH = 20     # Degrees nodding forward before alert
HEAD_YAW_THRESH   = 30     # Degrees turning sideways before alert

# ── Risk Score ───────────────────────────────────────────────────────────────
SCORE_ALERT = 50           # Score ≥ this → trigger alert
W_EAR       = 40           # EAR contribution weight   (%)
W_PERCLOS   = 35           # PERCLOS contribution weight (%)
W_HEAD      = 25           # Head pose contribution weight (%)
