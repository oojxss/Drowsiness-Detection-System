"""
DrowsyGuard — src/alerts.py
Handles alert triggering, cooldown, and logging.
Extend this to add sound (playsound) or SMS.
"""

import time
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

LOG_DIR = Path(__file__).parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)


class AlertManager:
    """
    Manages drowsiness alerts with cooldown and file logging.

    Parameters
    ----------
    cooldown_seconds : float
        Minimum seconds between consecutive alerts (avoids spam).
    log_file : str
        Name of the CSV log file inside /logs/.
    """

    def __init__(self, cooldown_seconds: float = 8.0,
                 log_file: str = "session.csv"):
        self._cooldown  = cooldown_seconds
        self._last_time = 0.0
        self._count     = 0
        self._log_path  = LOG_DIR / log_file
        self._init_log()

    def _init_log(self) -> None:
        with open(self._log_path, "w") as f:
            f.write("timestamp,alert_num,score,ear,perclos\n")

    def trigger(self, score: int, ear: float, perclos: float) -> bool:
        """
        Fire an alert if cooldown has elapsed.
        Returns True if alert was actually fired.
        """
        now = time.time()
        if now - self._last_time < self._cooldown:
            return False

        self._last_time = now
        self._count    += 1
        self._write_log(score, ear, perclos)
        logger.warning(
            f"[ALERT #{self._count}] score={score} "
            f"EAR={ear:.3f} PERCLOS={perclos:.1%}"
        )
        return True

    def _write_log(self, score: int, ear: float, perclos: float) -> None:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(self._log_path, "a") as f:
            f.write(f"{ts},{self._count},{score},{ear:.4f},{perclos:.4f}\n")

    @property
    def count(self) -> int:
        return self._count
