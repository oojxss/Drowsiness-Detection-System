# Contributing to DrowsyGuard

Thank you for your interest! Here's how to contribute.

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/drowsyguard.git
cd drowsyguard
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

## Making Changes

1. Fork the repo and create a branch: `git checkout -b feature/your-feature`
2. Make your changes
3. Run tests: `pytest tests/ -v`
4. Commit: `git commit -m "feat: describe your change"`
5. Open a Pull Request

## Ideas for Contributions

- Audio alert support (playsound / pygame)
- MediaPipe backend alternative to dlib
- Flask web dashboard for live metrics
- Dataset evaluation script
- Docker container setup

## Code Style

- Follow PEP 8
- Add docstrings to all public functions
- Add a test for any new function in `tests/`
